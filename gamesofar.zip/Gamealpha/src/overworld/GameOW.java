package overworld;

import java.util.ArrayList;

import org.lwjgl.Sys;
import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import static org.lwjgl.opengl.GL11.*;

public class GameOW {

	//Name of the title window
	private String WINDOW_TITLE = "GameAlpha";

	//Width of the game display area.
	private int width = 800;

	//Height of the game display area.
	private int height = 600;

	//Loader responsible for converting images into OpenGL textures.
	private TextureLoader textureLoader;

	//List to hold all the entities in the game.
	private ArrayList<Entity> entities = new ArrayList<Entity>();

	//List of entites to be removed this loop
	private ArrayList<Entity> removelst = new ArrayList<Entity>();

	//private ShipEntity ship;

	//private ShotEntity[] shots;

	//private Sprite message;

	//private Sprite pressAnyKey;

	//private Sprite youWin;

	//private Sprite youLose;

	//How many shots we have or whatever, need to get rid of this
	private int shotindex;

	
	//This seems helpful
	private float movespeed = 300;

	//This probably not
	private long lastfire;

	//Umm.. 
	private long firinginterval = 500;

	//Probably needs to be like npc count
	private int aliencount;

	private boolean waitingforkeypress = true;

	//True if game logic needs to applied this loop, due to some game event
	private boolean logicRequiredThisLoop;

	private long lastLoopTime = getTime();

	private static long timerTicksPerSecond = Sys.getTimerResolution();

	private boolean fireHasBeenReleased;

	private long lastFpsTime;

	private int fps;

	public static boolean gameRunning = true;
	
	private boolean fullscreen;

	private SoundManager soundManager;
	
	//private int SOUND_SHOT;
	
	//private int SOUND_HIT;
	
	//private int SOUND_START;
	
	//private int  SOUND_WIN;
	
	//private int SOUND_LOSE;
	
	private int mouseX;
	
	private static boolean isapplication;
	
	public GameOW(boolean fullscreen){
		this.fullscreen = fullscreen;
		this.initialize();
	}
	
	public void initialize(){
		
	}
	
	



	private static long getTime(){
		return (Sys.getTime() * 1000) / timerTicksPerSecond;
	}
}




