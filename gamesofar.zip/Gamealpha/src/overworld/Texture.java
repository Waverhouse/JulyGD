package overworld;

import static org.lwjgl.opengl.GL11.*;

public class Texture {
	
	//GL target type?
	private int target;

	//GL texture id
	private int textureID;
	
	//Height of the image
	private int height;
	
	//Width of the image
	private int width;
	
	//width of the texture
	private int texWidth;
	
	//Height of the texture.
	private int texHeight;
	
	//Ratio of width from image to text
	private float widthRatio;
	
	//Ratio of the height from image to text
	private float heightRatio;
	
	/**
	 * Create a new texture
	 */
	public Texture(int target, int textureID){
		this.target = target;
		this.textureID = textureID;
	}
	
	
	/**
	 * Bind the specified GL context to a texture?
	 */
	public void bind(){
		glBindTexture(this.target, this.textureID);
	}
	
	/**
	 * Set the height of the image
	 */
	public void setHeight(int height){
		this.height = height;
		setHeight();
	}
	
	/**
	 * Set the width of the image
	 * @param width
	 */
	public void setWidth(int width){
		this.width = width;
		setWidth();
	}
	
	public int getImageHeight(){
		return this.height;
	}
	
	public int getImageWidth(){
		return this.width;
	}
	
	public float getHeightR(){
		return this.heightRatio;
	}
	
	public float getWidthR(){
		return this.widthRatio;
	}
	
	/**
	 * Set the width of this texture
	 * @param texWidth
	 */
	public void setTextureWidth(int texWidth){
		this.texWidth = texWidth;
		setWidth();
	}
	
	/**
	 * Set the height of this texture
	 * @param texHeight
	 */
	public void setTextureHeight(int texHeight){
		this.texHeight = texHeight;
		setHeight();
	}
	
	/**
	 * Update the height ratio.
	 */
	private void setHeight(){
		if(texHeight != 0){
			widthRatio = ((float) width)/ texWidth;
		}
	}
	
	/**
	 * Update width ratio
	 */
	private void setWidth(){
		if(texWidth !=0 ){
			widthRatio = ((float) width) / texWidth;
		}
	}
	
	
	
	
}
